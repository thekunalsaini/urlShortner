# a URL shortener example app!

## getting up and running

You'll want to locally install the app

```bash
npm i 
```

You'll then want to create a copy of `example.env` in the root of the project and call this copy `.env`. Once that is done, replace the place-holder values with real values.

To start the app locally, you can run `npm run dev` and go to `http://localhost:3000`.
